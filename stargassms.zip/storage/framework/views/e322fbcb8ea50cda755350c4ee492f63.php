<?php $__env->startSection("content"); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.ManagerLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/manager/releves.blade.php ENDPATH**/ ?>