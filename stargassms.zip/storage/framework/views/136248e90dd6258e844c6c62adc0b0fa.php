 
 <?php $__env->startSection("content"); ?>
 <div class="mx-10">
     <h1 class="text-2xl  font-bold ml-12">Historique des Mouvements </h1>
     <div class="w-full   border-2 border-gray-300 rounded-md">
        <div class="w-full  bg-gray-600 text-white py-2 px-4 flex justify-between">
            Filtre
            <span class="show-filter font-bold text-3xl cursor-pointer">-</span>
        </div>
        <div class="w-full p-3 filter-content">
            <form action="<?php echo e(route("manager-filtered-history")); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <div class="flex gap-5">
                <div class="champs">
                    <label for="">De</label><br>
                    <input name="fromdate" type="date" id="">
                    <?php if($errors->has("fromdate")): ?>
                        <p class="text-red-500"><?php echo e($errors->first("fromdate")); ?></p>
                    <?php endif; ?>
                </div>
                <div class="champs">
                    <label for="">Jusqu'a</label><br>
                    <input name="todate" type="date" id="date"
                     required>
                     <?php if($errors->has("todate")): ?>
                         <p class="text-red-500"><?php echo e($errors->first("todate")); ?></p>
                     <?php endif; ?>
                </div>
            </div>
            <div class="flex mt-2">
                <div >
                    <label for="">Article</label>
                <select name="type" class="w-full h-10" id="">
                    <option value="bouteilles-pleines">Bouteilles pleines</option>
                    <option value="bouteilles-vides">Bouteilles vides</option>
                    <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <option value="<?php echo e($accessory->title); ?>"><?php echo e($accessory->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php if($errors->has("type")): ?>
                <p class="text-red-500"><?php echo e($errors->first("type")); ?></p>
            <?php endif; ?>
                </div>
            </div>
            <button type="submit" class="mt-4 bg-blue-400 text-white p-2">Appliquer</button>
        </form>
        </div>
     </div>
     <br>
 </div>
     <h1 class="font-bold text-2xl">Historique des entrees</h1>
     <br>
     <div>
         <table class="history scroll mt-10 w-full border-2 border-gray-400 border-collapse-0">
            <thead class="p-2 bg-gray-500 text-white">
                <tr>
                    <td>Date</td>
                    <td>identifiant</td>
                    <td>origin</td>
                    <td>article</td>
                    <td>entree</td>
                    <td>qte</td>
                    <td>bordereau</td>
                    <td>stock</td>
                    <td>state</td>
                    <td>commentaire</td>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $allMoves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $move): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                    <tr id="<?php echo e($move->id); ?>" class="hover:text-white hover:bg-blue-400 hover:cursor-pointer">
                        <td><?php echo e($move->created_at); ?></td>
                        <td><?php echo e($move->id); ?></td>
                        <td><?php echo e($move->origin); ?></td>
                        <td><?php echo e($move->fromArticle->type); ?> - <?php echo e($move->fromArticle->weight); ?> KG </td>
                        <td><?php echo e($move->entree); ?></td>
                        <td><?php echo e($move->qty); ?></td>
                        <td><?php echo e($move->bordereau); ?></td>
                        <td><?php echo e($move->stock); ?></td>
                        <td><?php echo e($move->fromArticle->state? "plein":"vide"); ?></td>
                        <td><?php echo e($move->label); ?> <span class="text-red-500 delete"> supprimer</span></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
     </div>
     <br>
     <h1 class="font-bold text-2xl">Historique des Sortie</h1>
     <br>
     <div>
         <table class=" scroll mt-10 w-full border-2 border-gray-400 border-collapse-0">
            <thead class="p-2 bg-gray-500 text-white">
                <tr>
                    <td>Date</td>
                    <td>identifiant</td>
                    <td>origin</td>
                    <td>article</td>
                    <td>sortie</td>
                    <td>qte</td>
                    <td>Bordereau</td>
                    <td>stock</td>
                    <td>state</td>
                    <td>commentaire</td>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $allMovesOut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $move): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr  id="<?php echo e($move->id); ?>" class="hover:text-white move-row hover:bg-blue-400 hover:cursor-pointer">
                        <td><?php echo e($move->created_at); ?></td>
                        <td><?php echo e($move->id); ?></td>
                        <td><?php echo e($move->origin); ?></td>
                        <td><?php echo e($move->fromArticle->type); ?> - <?php echo e($move->fromArticle->weight); ?> KG </td>
                        <td><?php echo e($move->sortie); ?></td>
                        <td><?php echo e($move->qty); ?></td>
                        <td><?php echo e($move->bordereau); ?></td>
                        <td><?php echo e($move->stock); ?></td>
                        <td><?php echo e($move->fromArticle->state? "plein":"vide"); ?></td>
                        <td><?php echo e($move->label); ?> <span class="text-red-500 delete"> supprimer</span></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
     </div>
    </div>
     <script>
        $( function () {
    $('table').DataTable();
    //evement sur les historiques
$(".show-filter").on("click",function(){
    $(".filter-content").toggleClass("hidden")
})
    $(".delete").on("click",function(){
        id = $(this).parent().parent().attr("id");
   
        var token = $("meta[name='csrf-token']").attr("content");
        $.ajax({
            url:"/manager/DeleteMove/"+id,
            dataType:"json",
            data: {
                "id": id,
                "_token": token,
            },
            method:"DELETE",
            success:function(res){
                toastr.warning(res.message)
                $("#"+id).load(location.href+ " #"+id)
            },
        })
    })
} );
     </script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.ManagerLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/manager/history.blade.php ENDPATH**/ ?>