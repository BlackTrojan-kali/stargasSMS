<div>
    <!-- I begin to speak only when I am certain what I will say is not better left unsaid. - Cato the Younger -->
</div>
<?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/moveEntry.blade.php ENDPATH**/ ?>