
<?php $__env->startSection("content"); ?>
<div class="mt-8 p-2">
    <div class=" mb-2 flex justify-end p-3 ">
        <a href="<?php echo e(route("create-region")); ?>" class="p-4 bg-green-400 text-white font-bold">Ajouter une region</a>
    </div>
    <table class="w-full table-auto bg-slate-200 border-separate p-2">
        <thead class="text-center font-bold py-12">
            <tr class="">
                <td>id</td>
                <td>Nom Region</td>
            </tr>
            <tbody>
                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="mb-5 text-center">
                    <td><?php echo e($region->id); ?><s/td>
                    <td><?php echo e($region->region); ?></td>
                    <td>
                        <a  id =<?php echo e($region->id); ?> class="delete px-4 p-1 rounded-md bg-red-500 text-white"><i class="fa-solid fa-trash"></i></a>
                    </td>
                </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <br>
            </tbody>
        </thead>
    </table>
</div>

<script>
$(document).ready(function(){
        $(".delete").on("click",function(e){
            e.preventDefault()
            userId = $(this).attr('id');
            Swal.fire({
  title: "Etes vous sures ? cette operation est irreversible",
  showDenyButton: true,
  showCancelButton: true,
  confirmButtonText: "Supprimer",
  denyButtonText: `Annuler`
}).then((result) => {
  /* Read more about isConfirmed, isDenied below */
  if (result.isConfirmed) {
    $.ajax({
        type:"DELETE",
        url:"region-delete/"+userId,
        dataType:"json",
        data:{
            "id":userId,
            "_token":"<?php echo e(csrf_token()); ?>"
        },
        success:function(res){
            Swal.fire("element supprime avec success", "", "success");
           $('table').load(" table")
        }
    })
  } else if (result.isDenied) {
    Swal.fire("Changement non enregistre", "", "info");
  }
});
          
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.appLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/region_list.blade.php ENDPATH**/ ?>