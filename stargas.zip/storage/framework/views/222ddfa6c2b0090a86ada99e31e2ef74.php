
<?php $__env->startSection('content'); ?>
    <center>
        <h1 class="text-2xl font-bold">historique des productions</h1>
        <div>
            <table class=" scroll mt-10 w-full border-2 border-gray-400 border-collapse-0">
                <thead class="text-white font-bold bg-slate-600 p-2">
                    <tr>
                        <td>S\L</td>
                        <td>Citerne</td>
                        <td>type</td>
                        <td>Qte</td>
                        <td>Borde. Prod</td>
                        <td>date</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id=<?php echo e($data->id); ?> class="hover:bg-blue-400 hover:text-white cursor-pointer">
                            <td><?php echo e($data->id); ?></td>
                            <td><?php echo e($data->citerne->name); ?> (<?php echo e($data->citerne->type); ?>)</td>
                            <td><?php echo e($data->type); ?></td>
                            <td><?php echo e($data->qty); ?></td>
                            <td><?php echo e($data->bordereau); ?></td>
                            <td><?php echo e($data->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </center>
    <script>
        $(function() {
            $('table').DataTable();
            //evement sur les historiques
            $(".delete").on("click", function() {
                id = $(this).parent().parent().attr("id");

                var token = $("meta[name='csrf-token']").attr("content");
                Swal.fire({
                    title: "Etes vous sures ? cette operation est irreversible",
                    showDenyButton: true,
                    showCancelButton: true,
                    confirmButtonText: "Supprimer",
                    denyButtonText: `Annuler`
                }).then((result) => {
                    /* Read more about isConfirmed, isDenied below */
                    if (result.isConfirmed) {
                        $.ajax({
                            url: "/manager/DeleteRec/" + id,
                            dataType: "json",
                            data: {
                                "id": id,
                                "_token": token,
                            },
                            method: "DELETE",
                            success: function(res) {
                                toastr.warning(res.message)
                                $("#" + id).load(location.href + " #" + id)
                            },
                        })
                    } else if (result.isDenied) {
                        Swal.fire("Changement non enregistre", "", "info");
                    }
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.controllerLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/controller/ProdMoves.blade.php ENDPATH**/ ?>