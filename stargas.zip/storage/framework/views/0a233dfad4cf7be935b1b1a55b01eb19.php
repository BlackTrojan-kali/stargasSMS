<?php $__env->startSection("content"); ?>

<h1 class="text-center font-bold text-2xl my-4">Accueil</h1>
<div class="w-full mx-5  grid grid-cols-2 gap-10">
  <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
    $percent = ($stock->qty/30000) *100
    ?>
  <div class="relative w-7/12">
    <div class="w-11/12 flex justify-between font-bold">
      <p><?php echo e($stock->article->title); ?> <span class="genera;"><?php echo e($stock->article->weight>0? $stock->article->weight."kg":""); ?> </span>
        <?php if($stock->type == "bouteille-gaz"): ?>
        <span class="text-green-500"><?php echo e($stock->article->state? "pleine":"vide"); ?></span>
        <?php endif; ?>  <span class="text-orange-500"><?php echo e($stock->region); ?> <?php echo e($stock->category); ?></span></p>
      <p><?php echo e($stock->qty); ?></p>
    </div>
    <div class="w-full bg-gray-300 h-8 rounded-e-full">
    
    </div>
    <div class="primary h-8 top-6   rounded-e-full absolute" style="width:<?php echo e($percent); ?>%"></div>
  </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.appLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/dashboard.blade.php ENDPATH**/ ?>