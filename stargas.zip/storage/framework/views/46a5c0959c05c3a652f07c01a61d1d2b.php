
<?php $__env->startSection('content'); ?>
    <center>
        <h1 class="text-2xl font-bold">Versements Global <?php echo e($type); ?></h1>
        <div>
            <table class=" scroll text-center mt-10 w-full border-2 border-gray-400 border-collapse-0">
                <thead class="bg-gray-500 text-white p-2 border-collapse-0">
                    <tr>
                        <th>Date</th>
                        <th>Versements</th>
                        <th>Bank</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $versements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $versement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($versement->mois); ?>/<?php echo e($versement->annee); ?> </td>
                            <td><?php echo e($versement->total_gpl); ?></td>
                            <td><?php echo e($versement->bank); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.DirectionLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/director/globalCA.blade.php ENDPATH**/ ?>