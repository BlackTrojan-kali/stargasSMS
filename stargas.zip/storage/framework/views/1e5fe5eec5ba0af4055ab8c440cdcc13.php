
<?php $__env->startSection('content'); ?>
    <center>
        <h1 class="font-bold text-2xl">Etat du Stock</h1>
        <table class=" scroll mt-10 w-full border-2 border-gray-400 border-collapse-0">
            <thead class="text-white font-bold text-center bg-slate-600 p-2">
                <tr>
                    <td>S/L</td>
                    <td>Citerne</td>
                    <td>Stock Theo</td>
                    <td>Stock Releve</td>
                    <td>Ecart</td>
                    <td>Action</td>
                </tr>
            </thead>
            <tbody class="bg-orange-200 text-center">
                <?php $__currentLoopData = $fixe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($fix->id); ?></td>
                        <td><?php echo e($fix->name); ?>-<?php echo e($fix->type); ?></td>
                        <td><?php echo e($fix->stock[0]->stock_theo); ?></td>
                        <td><?php echo e($fix->stock[0]->stock_rel); ?></td>
                        <?php
                        $ecart = $fix->stock[0]->stock_rel - $fix->stock[0]->stock_theo;
                        ?>
                        <td>
                            <?php if($ecart > 0): ?>
                                <span class="text-green-500"><?php echo e($ecart); ?></span>
                            <?php else: ?>
                                <span class="text-red-500"><?php echo e($ecart); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('makeRel', ['id' => $fix->id])); ?>">
                                <button class="bg-blue-400 p-2 text-white rounded-md">Nouveau releve</button>
                            </a>
                            <a href="<?php echo e(route('modif', ['id' => $fix->id])); ?>">
                                <button class="bg-blue-400 p-2 text-white rounded-md">Modifier Stock Theo

                                </button>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.ManagerLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/manager/citernes.blade.php ENDPATH**/ ?>