
<?php $__env->startSection('content'); ?>
    <div>
        <center>

            <div class="modal-active">
                <div class="bg-gray-700 text-white p-2 rounded-sm font-bold text-center">
                    <h1>Modifier mouvement</h1>
                </div>
                <span class="success text-green-500"></span>
                <span class="errors text-red-500"></span>
                <form action="<?php echo e(route('update-move-pro', $move->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-champs">
                        <label for="">Type d'operation:</label>
                        <select name="origin" id="">

                            <option value="<?php echo e($move->origin); ?>"><?php echo e($move->origin); ?></option>
                            <?php if(Auth::user()->region != 'central'): ?>
                                <option value="client">Client</option>
                                <option value="magasin central">MAGASIN CENTRAL</option>
                            <?php endif; ?>
                            <?php if(Auth::user()->region == 'central'): ?>
                                <option value="achat">achat</option>
                            <?php endif; ?>
                            <option value="region">region</option>
                            <option value="production">production</option>
                            <option value="stock_initial">stock initial</option>
                        </select>
                        <?php if($errors->has('origin')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('origin')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Quantite : </label>
                        <input type="number" name="qty" value="<?php echo e($move->qty); ?>" required>
                        <?php if($errors->has('qty')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('qty')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Libelle </label>
                        <input type="text" name="label" value="<?php echo e($move->label); ?>" required>
                        <?php if($errors->has('label')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('label')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Bordereau :</label>
                        <input type="text" name="bord" value="<?php echo e($move->bordereau); ?>" required>
                        <?php if($errors->has('bord')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('bord')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-champs">
                        <label for="">Quantite du stock : </label>
                        <input type="number" name="stock_qty" value="<?php echo e($move->stock); ?>" required>
                        <?php if($errors->has('qty')): ?>
                            <span class="text-red-500"><?php echo e($errors->first('stock_qty')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="modal-validation">
                        <button type="reset">annuler</button>
                        <button type="submit" id="submitForm">Modifier</button>
                    </div>
                    <div id="loading" style="display:none;" class=" text-yellow-500">enregistrement...
                    </div>
                </form>
            </div>
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.ProducerLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/producer/modifMove.blade.php ENDPATH**/ ?>