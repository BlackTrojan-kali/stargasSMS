
<?php $__env->startSection('content'); ?>
<center>
    <h1 class="text-xl font-bold">Ajouter une nouvelle Region</h1>
    <form action="<?php echo e(route('store-region')); ?>" method="post" class="md:w-4/12 border-2 mt-2 p-5 border-blue-400 rounded-md">
        <?php echo csrf_field(); ?>
        <div class="champs">
            <label for="username">Nom:</label>
            <input type="text" name="region" required>
            <?php if($errors->has("region")): ?>
                <p class="text-red-500"> <?php echo e($errors->first('region')); ?></p>
            <?php endif; ?>
        </div>
        </div>
        <div class="w-full flex justify-between mt-4">
            <button type="reset" class="p-2 bg-black text-white">Annuler</button>
            <button type="submit" class="p-2 bg-blue-400 text-white">Enregistrer</button>
        </div>
    </form>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("Layouts.appLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/region_create.blade.php ENDPATH**/ ?>