
<?php $__env->startSection('content'); ?>
    <div>
        <!-- ventes FORMULAIRES -->
        <div>
            <center>
                <div class="modal-active w-full md-6/12">
                    <div class="modal-head">
                        <h1>Modifier <?php echo e($sale->type); ?></h1>
                        <b class="close-modal">X</b>
                    </div>
                    <b class="success text-green-500"></b>
                    <b class="errors text-red-500"></b>
                    <form action="<?php echo e(route('updateSale', $sale->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="w-full text-center">
                            <label for="">Type de bouteilles</label>
                            <div class="w-full flex gap-1 sub-form">
                                <div class=" ">
                                    6kg
                                    <div class="flex gap-2">
                                        <input type="number" name="prix_6" value="<?php echo e($sale->prix_6); ?>"
                                            placeholder="prix U" required>
                                        <input type="number" name="qty_6" value="<?php echo e($sale->qty_6); ?>" placeholder="qte"
                                            id="" required>
                                    </div>
                                </div>
                                <div class=" ">
                                    12.5kg

                                    <div class="flex  gap-2 ">
                                        <input type="number" name="prix_12" value="<?php echo e($sale->prix_12); ?>"
                                            placeholder="prix U" required>
                                        <input type="number" name="qty_12" value="<?php echo e($sale->qty_12); ?>" placeholder="qte"
                                            id="" required>
                                    </div>
                                </div>
                                <div class=" ">
                                    50 kg

                                    <div class="flex  gap-2 ">
                                        <input type="number" name="prix_50" value="<?php echo e($sale->prix_50); ?>"
                                            placeholder="prix U" required>
                                        <input type="number" name="qty_50" value="<?php echo e($sale->qty_50); ?>" placeholder="qte"
                                            id="" required>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal-champs">
                            <label for="">Nom Client</label>
                            <input type="text" name="costumer" value="<?php echo e($sale->customer); ?>" required>
                            <?php if($errors->has('costumer')): ?>
                                <b class="text-red-500"><?php echo e($errors->first('costumer')); ?></b>
                            <?php endif; ?>
                        </div>
                        <div class="modal-champs">
                            <label for="">Numero Client</label>
                            <input type="number" name="numero" value="<?php echo e($sale->number); ?>" required>
                            <?php if($errors->has('numero')): ?>
                                <b class="text-red-500"><?php echo e($errors->first('numero')); ?></b>
                            <?php endif; ?>
                        </div>
                        <div class="modal-champs">
                            <label for="">Adresse du client :</label>
                            <input type="text" name="address" value="<?php echo e($sale->address); ?>" id="unit_price" required>
                            <?php if($errors->has('text')): ?>
                                <b class="text-red-500"><?php echo e($errors->first('text')); ?></b>
                            <?php endif; ?>
                        </div>

                        <div class="modal-champs">
                            <label for="">Type de Paiement</label>
                            <select name="currency">
                                <object data="<?php echo e($sale->currency); ?>" type=""><?php echo e($sale->currency); ?></object>
                                <option value="cash">Cash</option>
                                <option value="virement">Virement</option>
                            </select>
                            <?php if($errors->has('currency')): ?>
                                <b class="text-red-500"><?php echo e($errors->first('currency')); ?></b>
                            <?php endif; ?>
                        </div>
                        <div class="modal-champs">
                            <h2>Montant : <b></b></h2>
                        </div>
                        <div class="modal-validation">
                            <button type="reset">annuler</button>
                            <button type="submit" id="submitForm">modifier</button>
                        </div>
                    </form>
                </div>
            </center>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.comLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/commercial/ModifSale.blade.php ENDPATH**/ ?>