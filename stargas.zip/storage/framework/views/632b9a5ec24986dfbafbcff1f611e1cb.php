
<?php $__env->startSection('content'); ?>
    <style>
        td,
        th {
            border: 1px solid black;
            padding: 8px;
        }
    </style>
    <center>
        <h1 class="text-3xl font-bold underline">Bouteilles Vides</h1>
        <div class="w-full block">
            <!-- The biggest battle is the war against ignorance. - Mustafa Kemal Atatürk -->
            <table class="border-2 border-black ">
                <thead class="bg-gray-500 text-white ">
                    <tr>
                        <th colspan="3">MVT DU STOCK TOTAL</th>
                        <th>Dates</th>
                        <th>Libelles</th>
                        <th colspan="3">MVT EN MAGASIN DES BOUTEILLES VIDES</th>
                    </tr>
                    <tr class="border border-black">
                        <th>Achats</th>
                        <th>Ventes</th>
                        <th>Pertes</th>
                        <th>

                        </th>
                        <th> </th>
                        <th>ENTREES</th>
                        <th>SORTIES</th>
                        <th>STOCKS</th>
                    </tr>
                </thead>
                <tr class="border border-black">
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>

                    </td>
                    <td> </td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tbody>

                    <?php $__currentLoopData = $bouteille_vides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-blue-400 hover:text-white hover:cursor-pointer">
                            <td>
                                <?php echo e($data->origin == 'ventes' ? $data->qty : 0); ?>

                            </td>
                            <td>
                                <?php echo e($data->origin == 'achat' ? $data->qty : 0); ?></td>
                            <td>
                                <?php echo e($data->origin == 'pertes' ? $data->qty : 0); ?></td>
                            <td><?php echo e($data->created_at); ?></td>
                            <td><?php echo e($data->label); ?></td>
                            <td><?php echo e($data->entree ? $data->qty : 0); ?></td>
                            <td><?php echo e($data->sortie ? $data->qty : 0); ?></td>
                            <td><?php echo e($data->stock); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <h1 class="text-3xl font-bold underline">Bouteilles Pleines</h1>
            <table class="border-2 border-black">
                <thead class="bg-gray-500 text-white ">
                    <tr>
                        <th colspan="3">MVT DU STOCK TOTAL</th>
                        <th>Dates</th>
                        <th>Libelles</th>
                        <th colspan="3">MVT EN MAGASIN DES BOUTEILLES PlEINES</th>
                    </tr>
                    <tr class="border border-black">
                        <th>Achats</th>
                        <th>Ventes</th>
                        <th>Pertes</th>
                        <th>

                        </th>
                        <th> </th>
                        <th>ENTREES</th>
                        <th>SORTIES</th>
                        <th>STOCKS</th>
                    </tr>
                </thead>
                <tr class="border border-black">
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>

                    </td>
                    <td> </td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tbody>
                    <?php $__currentLoopData = $bouteille_pleines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-blue-400 hover:text-white hover:cursor-pointer">
                            <td>
                                <?php echo e($data->origin == 'ventes' ? $data->qty : 0); ?>

                            </td>
                            <td>
                                <?php echo e($data->origin == 'achat' ? $data->qty : 0); ?></td>
                            <td>
                                <?php echo e($data->origin == 'pertes' ? $data->qty : 0); ?></td>
                            <td><?php echo e($data->created_at); ?></td>
                            <td><?php echo e($data->label); ?></td>
                            <td><?php echo e($data->entree ? $data->qty : 0); ?></td>
                            <td><?php echo e($data->sortie ? $data->qty : 0); ?></td>
                            <td><?php echo e($data->stock); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.ManagerLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/manager/moveGlobalMan.blade.php ENDPATH**/ ?>