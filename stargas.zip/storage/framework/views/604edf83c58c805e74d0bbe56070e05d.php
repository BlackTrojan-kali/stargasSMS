
<?php $__env->startSection('content'); ?>
    <center>
        <div class="w-4/12 border-2 border-black p-5 text-start relative">
            <a href="<?php echo e(Auth::user()->role == 'producer' ? route('showCiterne') : route('showCiterneMan')); ?>"
                class="bg-gray-500 p-2 rounded-full text-white">retour</a>
            <h1 class="text-center font-bold text-2xl">Modifier le stock theorique</h1>
            <form action="<?php echo e(route('postModif', $citerne->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <br>
                <div class="">
                    <label for="" class="text-2xl">Nom Citerne:</label><br>
                    <span class="font-bold text-blue-400  text-xl"><?php echo e($citerne->name); ?></span>
                </div>
                <div class="">
                    <label for="" class="text-xl">qte theo:</label><br>
                    <input type="number" placeholder="quantite relever " name="qty"
                        class="p-2 w-full border  border-black mt-2 h-10">
                    <?php if($errors->has('qty')): ?>
                        <span><?php echo e($errors->first('qty')); ?></span>
                    <?php endif; ?>
                </div>

                <br>
                <div class="text-end">

                    <button class="bg-gray-400 p-2 text-white">appliquer</button>
                </div>
            </form>
        </div>
    </center>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.ManagerLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chendjou silinou joe\Documents\Projects\Lab\stargasSMS\stargasSMS\resources\views/ModifStock.blade.php ENDPATH**/ ?>