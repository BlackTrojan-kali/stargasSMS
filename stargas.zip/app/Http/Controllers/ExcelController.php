<?php

namespace App\Http\Controllers;

use App\Exports\MovementExport;
use App\Http\Controllers\Controller;
use App\Models\Movement;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class ExcelController extends Controller
{
    //
    public function export()
    {
        return Excel::download(new MovementExport, "movements.xlsx");
    }
}
