<?php

namespace App\Exports;

use App\Models\Movement;
use Maatwebsite\Excel\Concerns\FromCollection;

class MovementExport implements FromCollection
{

    private $depart;
    private $fin;
    private $type;
    private $etat;
    private $service;
    private $region;
    /**
     * @return \Illuminate\Support\Collection
     */
    public function __construct(string $depart, string $fin, string $type, bool $etat, string $service, string $region)
    {
        $this->depart = $depart;
        $this->fin = $fin;
        $this->type = $type;
        $this->etat = $etat;
        $this->service = $service;
        $this->region = $region;
    }
    public function collection()
    {
        $movesP =  Movement::leftjoin("articles", "movements.article_id", "articles.id")->leftjoin("stocks", "movements.stock_id", "stocks.id")->whereBetween("movements.created_at", [$this->depart, $this->fin])->where("movements.service", $this->service)->where("stocks.region", $this->region)->where("articles.type", "bouteille-gaz")->where("articles.weight", floatval($this->type))->where("articles.state", 1)->with("fromArticle")->select("movements.*")->orderBy("id")->get();
        
    }
}